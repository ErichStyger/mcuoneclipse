/*
 * Platform.h
 *
 *  Created on: 20.05.2014
 *      Author: tastyger
 */

#ifndef PLATFORM_H_
#define PLATFORM_H_


#define PL_HAS_SD_CARD  0 /* if we have SD card support */


#endif /* PLATFORM_H_ */
