/*
 * SysView.h
 *
 *  Created on: 04.07.2018
 *      Author: Erich Styger
 */

#ifndef SYSVIEW_H_
#define SYSVIEW_H_

void SysView_Init(void);

#endif /* SYSVIEW_H_ */
