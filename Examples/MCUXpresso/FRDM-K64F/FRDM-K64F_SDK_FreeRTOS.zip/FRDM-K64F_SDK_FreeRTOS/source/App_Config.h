/*
 * App_Config.h
 *
 *  Created on: 06.07.2018
 *      Author: Erich Styger
 */

#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

#define APP_CONFIG_USE_SEGGER_SYSTEMVIEW   (1)  /* 1: SEGGER SystemView enabled; 0: disbled */

#endif /* APP_CONFIG_H_ */
