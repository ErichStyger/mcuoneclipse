/*
 * FreeRTOS_Timers.h
 *
 *  Created on: 03.07.2018
 *      Author: Erich Styger
 */

#ifndef FREERTOS_TIMERS_H_
#define FREERTOS_TIMERS_H_

void FreeRTOS_Timers_Init(void);

#endif /* FREERTOS_TIMERS_H_ */
