/*
 * InterProcessComm.h
 *
 *  Created on: 06.07.2018
 *      Author: Erich Styger
 */

#ifndef INTERPROCESSCOMM_H_
#define INTERPROCESSCOMM_H_

void IPC_Init(void);

#endif /* INTERPROCESSCOMM_H_ */
