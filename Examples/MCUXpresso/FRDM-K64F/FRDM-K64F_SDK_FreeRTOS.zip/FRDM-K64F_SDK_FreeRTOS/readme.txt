readme.txt
----------
this project is used to demonstrate different optimizations for FreeRTOS.


Notes:

