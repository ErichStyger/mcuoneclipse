/** ###################################################################
**     Filename  : Events.H
**     Project   : BadgeBoard
**     Processor : MCF51JM128VLK
**     Beantype  : Events
**     Version   : Driver 01.02
**     Compiler  : CodeWarrior ColdFireV1 C Compiler
**     Date/Time : 11.01.2009, 16:54
**     Abstract  :
**         This is user's event module.
**         Put your event handler code here.
**     Settings  :
**     Contents  :
**         LC_OnStatus            - void LC_OnStatus(byte status);
**         LC_OnData              - void LC_OnData(LC_tTxRxDesc *data);
**         uCOS1_OSTimeTickHook   - void uCOS1_OSTimeTickHook(void);
**         uCOS1_OSTaskStatHook   - void uCOS1_OSTaskStatHook(void);
**         uCOS1_OSTaskIdleHook   - void uCOS1_OSTaskIdleHook(void);
**         uCOS1_OSTCBInitHook    - void uCOS1_OSTCBInitHook(OS_TCB *ptcb);
**         uCOS1_OSTaskDelHook    - void uCOS1_OSTaskDelHook(OS_TCB *ptcb);
**         uCOS1_OSTaskCreateHook - void uCOS1_OSTaskCreateHook(OS_TCB *ptcb);
**         uCOS1_OSInitHookBegin  - void uCOS1_OSInitHookBegin(void);
**         uCOS1_OSInitHookEnd    - void uCOS1_OSInitHookEnd(void);
**         MPR08x1_OnPress        - void MPR08x1_OnPress(byte button);
**         MPR08x1_OnFault        - void MPR08x1_OnFault(byte reason);
**         TI1_OnInterrupt        - void TI1_OnInterrupt(void);
**
**     (c) Copyright UNIS, a.s. 1997-2008
**     UNIS, a.s.
**     Jundrovska 33
**     624 00 Brno
**     Czech Republic
**     http      : www.processorexpert.com
**     mail      : info@processorexpert.com
** ###################################################################*/

#ifndef __Events_H
#define __Events_H
/* MODULE Events */

#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "PE_Timer.h"
#include "LEDM1.h"
#include "Inhr1.h"
#include "LEDpin1.h"
#include "Inhr2.h"
#include "LEDpin2.h"
#include "Inhr3.h"
#include "LEDpin3.h"
#include "Inhr4.h"
#include "LEDpin4.h"
#include "Inhr5.h"
#include "LEDpin5.h"
#include "Inhr6.h"
#include "LEDpin6.h"
#include "Inhr7.h"
#include "LEDpin7.h"
#include "LED_Red.h"
#include "LEDpin8.h"
#include "LED_Green.h"
#include "LEDpin9.h"
#include "I2C1.h"
#include "TI1.h"
#include "MPR08x1.h"
#include "Attn1.h"
#include "Irq1.h"
#include "AD1.h"
#include "uCOS1.h"
#include "SWI1.h"
#include "TI2.h"
#include "WAIT1.h"
#include "ACCEL1.h"
#include "G11.h"
#include "G21.h"
#include "Sleep1.h"
#include "GDisp1.h"
#include "GFONT1.h"
#include "LiIon1.h"
#include "Enable1.h"
#include "PPR1.h"
#include "CHG1.h"
#include "PTA5.h"
#include "IRO.h"
#include "LC.h"
#include "LS.h"
#include "UTIL1.h"
#include "PPG1.h"

void LC_OnStatus(byte status);
/*
** ===================================================================
**     Event       :  LC_OnStatus (module Events)
**
**     From bean   :  LC [LightComm]
**     Description :
**         Event is called on communiation status change
**     Parameters  :
**         NAME            - DESCRIPTION
**         status          - 
**     Returns     : Nothing
** ===================================================================
*/

void LC_OnData(LC_tTxRxDesc *data);
/*
** ===================================================================
**     Event       :  LC_OnData (module Events)
**
**     From bean   :  LC [LightComm]
**     Description :
**         Event called on the event we received a data packet.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * data            - Pointer to a descriptor for the data we
**                           received.
**     Returns     : Nothing
** ===================================================================
*/

void uCOS1_OSTimeTickHook(void);
/*
** ===================================================================
**     Event       :  uCOS1_OSTimeTickHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called when a time tick event occurs. This
**         allows you to perform other operations during a time tick.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

void uCOS1_OSTCBInitHook(OS_TCB *ptcb);
/*
** ===================================================================
**     Event       :  uCOS1_OSTCBInitHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called on initialization of a task control
**         block.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * ptcb            - ptcp is a pointer to the task control
**                           block of the task being initialized.
**     Returns     : Nothing
** ===================================================================
*/

void uCOS1_OSTaskDelHook(OS_TCB *ptcb);
/*
** ===================================================================
**     Event       :  uCOS1_OSTaskDelHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called when a task is deleted. Note(s) : 1)
**         Interrupts are enabled during this call.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * ptcb            - ptcp is a pointer to the task control
**                           block of the task being deleted.
**     Returns     : Nothing
** ===================================================================
*/

void uCOS1_OSTaskCreateHook(OS_TCB *ptcb);
/*
** ===================================================================
**     Event       :  uCOS1_OSTaskCreateHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called when a task is created. Note(s) : 1)
**         Interrupts are enabled during this call.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * ptcb            - ptcp is a pointer to the task control
**                           block of the task being deleted.
**     Returns     : Nothing
** ===================================================================
*/

void MPR08x1_OnPress(byte button);
/*
** ===================================================================
**     Event       :  MPR08x1_OnPress (module Events)
**
**     From bean   :  MPR08x1 [MPR08x]
**     Description :
**         Event for a button pressed. You can disable this event if
**         you are not interested in it in order to save code size.
**     Parameters  :
**         NAME            - DESCRIPTION
**         button          - Button number, in the range 0 to 7.
**     Returns     : Nothing
** ===================================================================
*/

void MPR08x1_OnFault(byte reason);
/*
** ===================================================================
**     Event       :  MPR08x1_OnFault (module Events)
**
**     From bean   :  MPR08x1 [MPR08x]
**     Description :
**         This event is called in case of a fault sensor condition.
**         You can disable this event if you are not interested in it
**         in order to save code size.
**     Parameters  :
**         NAME            - DESCRIPTION
**         reason          - reason of fault: 1 for short to VSS
**                           detected, 2 for short to VDD detected, 3
**                           for FIFO overflow (see ON_MPR083_FAULT_xxx
**                           defines).
**     Returns     : Nothing
** ===================================================================
*/

void TI1_OnInterrupt(void);
/*
** ===================================================================
**     Event       :  TI1_OnInterrupt (module Events)
**
**     From bean   :  TI1 [TimerInt]
**     Description :
**         When a timer interrupt occurs this event is called (only
**         when the bean is enabled - <Enable> and the events are
**         enabled - <EnableEvent>). This event is enabled only if a
**         <interrupt service/event> is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/


void uCOS1_OSTaskSwHook(void);
/*
** ===================================================================
**     Event       :  uCOS1_OSTaskSwHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called when a task switch is performed.
**         This allows you to perform other operations during a context
**         switch. Notes: 1) Interrupts are disabled during this call.
**         2) It is assumed that the global pointer 'OSTCBHighRdy'
**         points to the TCB of the task that will be 'switched in' (i.
**         e. the highest priority task) and, 'OSTCBCur' points to the
**         task being switched out (i.e. the preempted task).
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

void ACCEL1_OnADGet(void);
/*
** ===================================================================
**     Event       :  ACCEL1_OnADGet (module Events)
**
**     Component   :  ACCEL1 [MMA7260Q]
**     Description :
**         Called to get mutual access to the A/D converter
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

void ACCEL1_OnADGive(void);
/*
** ===================================================================
**     Event       :  ACCEL1_OnADGive (module Events)
**
**     Component   :  ACCEL1 [MMA7260Q]
**     Description :
**         Called to give back mutual access to the A/D converter
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

/* END Events */
#endif /* __Events_H*/

/*
** ###################################################################
**
**     This file was created by UNIS Processor Expert 3.03 [04.07]
**     for the Freescale ColdFireV1 series of microcontrollers.
**
** ###################################################################
*/
