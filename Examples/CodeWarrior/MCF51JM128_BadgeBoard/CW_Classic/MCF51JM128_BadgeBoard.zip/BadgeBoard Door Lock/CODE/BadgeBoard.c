/** ###################################################################
**     Filename  : BadgeBoard.C
**     Project   : BadgeBoard
**     Processor : MCF51JM128VLK
**     Version   : Driver 01.00
**     Compiler  : CodeWarrior ColdFireV1 C Compiler
**     Date/Time : 11.01.2009, 16:54
**     Abstract  :
**         Main module.
**         This module contains user's application code.
**     Settings  :
**     Contents  :
**         No public methods
**
**     (c) Copyright UNIS, a.s. 1997-2008
**     UNIS, a.s.
**     Jundrovska 33
**     624 00 Brno
**     Czech Republic
**     http      : www.processorexpert.com
**     mail      : info@processorexpert.com
** ###################################################################*/
/* MODULE BadgeBoard */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "LEDM1.h"
#include "Inhr1.h"
#include "LEDpin1.h"
#include "Inhr2.h"
#include "LEDpin2.h"
#include "Inhr3.h"
#include "LEDpin3.h"
#include "Inhr4.h"
#include "LEDpin4.h"
#include "Inhr5.h"
#include "LEDpin5.h"
#include "Inhr6.h"
#include "LEDpin6.h"
#include "Inhr7.h"
#include "LEDpin7.h"
#include "LED_Red.h"
#include "LEDpin8.h"
#include "LED_Green.h"
#include "LEDpin9.h"
#include "I2C1.h"
#include "TI1.h"
#include "MPR08x1.h"
#include "Attn1.h"
#include "Irq1.h"
#include "AD1.h"
#include "uCOS1.h"
#include "SWI1.h"
#include "TI2.h"
#include "WAIT1.h"
#include "ACCEL1.h"
#include "G11.h"
#include "G21.h"
#include "Sleep1.h"
#include "GDisp1.h"
#include "GFONT1.h"
#include "LiIon1.h"
#include "Enable1.h"
#include "PPR1.h"
#include "CHG1.h"
#include "PTA5.h"
#include "IRO.h"
#include "LC.h"
#include "LS.h"
#include "UTIL1.h"
#include "PPG1.h"
/* Include shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "LedFont.h"

/*--------- TASKS ---------------------------*/
OS_FLAG_GRP *ButtonStatus; /* flags for electrode/buttons: bit 0 is electrode 1, and so on */

#define PL_HAS_ACCEL_GAME  1  /* if we have the acceleration game or not */

#define TASK_STK_SIZE  256

static OS_STK  BlinkStk[TASK_STK_SIZE];
static OS_STK  InitTaskStk[TASK_STK_SIZE];
static OS_STK  MainTaskStk[TASK_STK_SIZE];
static OS_STK  ButtonsTaskStk[TASK_STK_SIZE];
static OS_STK  SounderTaskStk[TASK_STK_SIZE];
static OS_STK  ScrollerTaskStk[TASK_STK_SIZE];

/* IDs and priorities for tasks: the lower the number the higher the priority */
#define TASK_PRIO_BUTTONS   30
#define TASK_PRIO_MAIN      31
#define TASK_PRIO_BLINK     32
#define TASK_PRIO_INIT      33
#define TASK_PRIO_SOUNDER   34
/*#define TASK_PRIO_SCROLLER  35 */

/* -------- Sounder ----------------- */
static word freqSounder = 300;

void StartSounder(word freq) {
  freqSounder = freq;
  uCOS1_OSTaskResume(TASK_PRIO_SOUNDER);
}

static void Sounder(void *pdata) {
  (void)pdata; /* avoid compiler warning */
  for(;;) {
    uCOS1_OSTaskSuspend(OS_PRIO_SELF); /* put task to sleep */
    PPG1_SetFreqHz(freqSounder);
    PPG1_Enable();
    (void)OSTimeDlyHMSM(0,0,0,50);
    PPG1_Disable();
    (void)OSTimeDlyHMSM(0,0,0,50);
    PPG1_Enable();
    (void)OSTimeDlyHMSM(0,0,0,50);
    PPG1_Disable();
  }
}
/* ------------------------- ACCEL GAME -------------- */
#if PL_HAS_ACCEL_GAME

#define NOF_TRAILS 7

typedef struct _PosInfo {
  byte x, y; /* x and y coordinate */
} PosInfo;

static PosInfo gamePixel[NOF_TRAILS];

static signed char AccelGameChangePos(byte accelValue) {
  #define ACCEL_MIDDLE_POS 110 /* middle position of acceleration sensor */
  #define ACCEL_MIDDLE_OFFSET 10
  
  if (accelValue>ACCEL_MIDDLE_POS+3*ACCEL_MIDDLE_OFFSET) {
    return -4; /* faster move */
  } else if (accelValue>ACCEL_MIDDLE_POS+2*ACCEL_MIDDLE_OFFSET) {
    return -2; /* faster move */
  } else if (accelValue>ACCEL_MIDDLE_POS+ACCEL_MIDDLE_OFFSET) {
    return -1;
  } else if (accelValue<ACCEL_MIDDLE_POS-3*ACCEL_MIDDLE_OFFSET) {
    return 4;  /* faster move */
  } else if (accelValue<ACCEL_MIDDLE_POS-2*ACCEL_MIDDLE_OFFSET) {
    return 2;  /* faster move */
  } else if (accelValue<ACCEL_MIDDLE_POS-ACCEL_MIDDLE_OFFSET) {
    return 1;
  }
  return 0; /* no change */
}

static AccelGameNewPixel(byte x, byte y) {
  byte i;

  for(i=0; i<NOF_TRAILS-1; i++) { /* check if we are not stepping on ourselves */
    if(x==gamePixel[i].x && y==gamePixel[i].y) {
      return; /* stepping on ourselves */
    }
  }
  GDisp1_ClrPixel(gamePixel[NOF_TRAILS-1].x, gamePixel[NOF_TRAILS-1].y); /* clear last one */
  for(i=NOF_TRAILS-1; i>0; i--) {
    gamePixel[i].x = gamePixel[i-1].x;
    gamePixel[i].y = gamePixel[i-1].y;
  }
  gamePixel[0].x = x;
  gamePixel[0].y = y;
  GDisp1_SetPixel(gamePixel[0].x, gamePixel[0].y); /* draw new pixel */

  for(i=0; i<NOF_TRAILS-1; i++) { /* coalesc other pixels */
    if (gamePixel[i].x<gamePixel[i+1].x-1) {
      /* more than 1 pixel apart: coalesce */
      GDisp1_ClrPixel(gamePixel[i+1].x, gamePixel[i+1].y); /* clear old Pixel */
      gamePixel[i+1].x = (byte)(gamePixel[i].x+1);
      gamePixel[i+1].y = (byte)(gamePixel[i].y);
      GDisp1_SetPixel(gamePixel[i+1].x, gamePixel[i+1].y); /* draw new Pixel */
    } else if (gamePixel[i].x>gamePixel[i+1].x+1) {
      /* more than 1 pixel apart: coalesce */
      GDisp1_ClrPixel(gamePixel[i+1].x, gamePixel[i+1].y); /* clear old Pixel */
      gamePixel[i+1].x = (byte)(gamePixel[i].x-1);
      gamePixel[i+1].y = (byte)(gamePixel[i].y);
      GDisp1_SetPixel(gamePixel[i+1].x, gamePixel[i+1].y); /* draw new Pixel */
    }
    if (gamePixel[i].y<gamePixel[i+1].y-1) {
      /* more than 1 pixel apart: coalesce */
      GDisp1_ClrPixel(gamePixel[i+1].x, gamePixel[i+1].y); /* clear old Pixel */
      gamePixel[i+1].y = (byte)(gamePixel[i].y+1);
      gamePixel[i+1].x = (byte)(gamePixel[i].x);
      GDisp1_SetPixel(gamePixel[i+1].x, gamePixel[i+1].y); /* draw new Pixel */
    } else if (gamePixel[i].y>gamePixel[i+1].y+1) {
      /* more than 1 pixel apart: coalesce */
      GDisp1_ClrPixel(gamePixel[i+1].x, gamePixel[i+1].y); /* clear old Pixel */
      gamePixel[i+1].y = (byte)(gamePixel[i].y-1);
      gamePixel[i+1].x = (byte)(gamePixel[i].x);
      GDisp1_SetPixel(gamePixel[i+1].x, gamePixel[i+1].y); /* draw new Pixel */
    }
  }
}

static void AccelGame(void) {
  signed char posX = -1, posY=-1;
  signed char cntr=-1;
  byte x, y; /* acceleration sensor values */
  byte i;
  INT8U err;

  LedFont_ScrollText("Accel Game", TRUE, TRUE);
  /* start of game */
  GDisp1_Clear();
  posX = GDisp1_GetWidth()/2; posY = GDisp1_GetHeight()/2; /* middle of display */
  for(i=0; i<NOF_TRAILS; i++) { /* init pixel trail array */
    gamePixel[i].x = (byte)posX;
    gamePixel[i].y = (byte)posY;
  }
  GDisp1_SetPixel(gamePixel[0].x, gamePixel[0].y); /* draw first pixel */
  for(;;) {
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&0x80) { /* electrode 8: quit */
      uCOS1_OSFlagPost(ButtonStatus, 0xFF, OS_FLAG_CLR, &err); /* clear all button flags */
      GDisp1_Clear();
      return;
    }
    ACCEL1_SensorOn();
    ACCEL1_MeasureX();
    ACCEL1_MeasureY();
    x = ACCEL1_GetX();
    y = ACCEL1_GetY();
    ACCEL1_SensorOff();
    posX += AccelGameChangePos(y);
    posY += AccelGameChangePos(x);
    /* keep position inside display boundaries */
    if (posX < 0) {
      posX = 0;
    } else if (posX>=GDisp1_GetWidth()) {
      posX = (signed char)GDisp1_GetWidth()-1;
    }
    if (posY < 0) {
      posY = 0;
    } else if (posY>=GDisp1_GetHeight()) {
      posY = GDisp1_GetHeight()-1;
    }
    AccelGameNewPixel((byte)posX, (byte)posY); /* draw pixel */
    (void)uCOS1_OSTimeDlyHMSM(0,0,0,100); /* wait for 100 ms */
  }
}
#endif /* PL_HAS_ACCEL_GAME */
/* -------- MoveX ----------------- */
static void MoveX(void) {
  INT8U err;
  unsigned char i = 0;

  LedFont_ScrollText("MoveX", TRUE, TRUE);
  for(;;) {
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&0x80) { /* electrode 8: quit */
      uCOS1_OSFlagPost(ButtonStatus, 0xFF, OS_FLAG_CLR, &err); /* clear all button flags */
      GDisp1_Clear();
      return;
    }
    GDisp1_ClrPixel(i, 0);
    i++;
    if (i == GDisp1_GetWidth()) {
      i = 0; /* start again */
    }
    GDisp1_SetPixel(i, 0);
    GDisp1_UpdateFull();
    (void)uCOS1_OSTimeDlyHMSM(0,0,0,50); /* wait for 50 ms */
  }
}
/* -------- LightComm ----------------- */
static LC_tTxRxDesc tx, rx;
static byte rxbuf[8];
static byte txbuf[8];

static void LightComm(char *msg) {
  byte res;
  byte err;

  if (msg!=NULL) {
    LedFont_ScrollText("Tx", TRUE, TRUE);
  } else {
    LedFont_ScrollText("Rx", TRUE, TRUE);
  }
  /* initialize communication data */
  tx.data = &txbuf[0];
  rx.data = &rxbuf[0];
  rx.nofBytes = sizeof(rxbuf);
  tx.nofBytes = sizeof(txbuf);
  if(msg != NULL) { /* send (and receive) */
    tx.nofBytes = (byte)(strlen(msg)+1);
    if (tx.nofBytes > sizeof(txbuf)) {
      tx.nofBytes = sizeof(txbuf);
    }
    UTIL1_strcpy((char*)tx.data, sizeof(txbuf), (const char*)msg);
  }
  LEDM1_Off();
  TI1_Disable(); /* disable display display refresh during communication */
  for(;;) {
    LED_Red_Neg();
    LED_Green_Neg();
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&0x80) { /* electrode 8: quit */
      break; /* return */
    }
    (void)uCOS1_OSTimeDlyHMSM(0,0,0,10);
    if (msg!=NULL || LS_GetVal()==0) { /* light received from the other side? */
      TI2_Disable(); /* disable RTOS during communication not to interrupt communication (time sensitive) */
      LED_Red_Off();
      LED_Green_Off();
      if(msg != NULL) { /* send (and receive) */
        res = LC_EnableRequest(&tx, &rx, 1);
      } else { /* receive */
        res = LC_EnableRequest((void*)0, &rx, 1);
      }
      TI2_Enable(); /* enable RTOS again */
      if (res == ERR_OK) { /* communication successful! */
        if (msg==NULL && rxbuf[0] == 'a') { /* rx mode */
          StartSounder(900);
          break; /* return */
        } else if(msg!=NULL) { /* tx mode */
          StartSounder(300);
          break; /* return */
        } else { /* error :-( */
          /* retry */
        }
      }
    }
  } /* for */
  TI1_Enable(); /* display refresh */
  LED_Red_Off();
  LED_Green_Off();
}
/* -------- LockDoor ----------------- */
static byte nofBits(word val) {
  byte cnt = 0;
  while (val!=0) {
    if (val&1) {
      cnt++;
    }
    val >>= 1;
  }
  return cnt;
}

static void LockDoor(void) {
  byte err;
  bool locked = TRUE;
  byte i = 0;

  /* initialize communication data */
  rx.data = &rxbuf[0];
  rx.nofBytes = sizeof(rxbuf);
  uCOS1_OSTaskSuspend(TASK_PRIO_BLINK);
  for(;;) {
    if (locked) {
      if (i==0) {
        LED_Red_On();
        LED_Green_Off();
        LedFont_ScrollText("Locked", TRUE, TRUE);
      }
      i++;
      if (i>20) {
        i = 0;
      }
    } else {
      LED_Red_Off();
      LED_Green_On();
      LedFont_ScrollText("Open", TRUE, TRUE);
    }
    if (!locked && uCOS1_OSFlagQuery(ButtonStatus, &err)&(1<<5)) { /* electrode 6: lock again */
      uCOS1_OSFlagPost(ButtonStatus, (1<<5), OS_FLAG_CLR, &err); /* clear flag */
      locked = TRUE;
    }
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&0x80) { /* electrode 8: quit */
      break; /* return */
    }
    (void)uCOS1_OSTimeDlyHMSM(0,0,0,50);
    /* no check if there is a badge asking for opening the door */
    LEDM1_Off();
    TI1_Disable(); /* disable display display refresh during communication */
    if (locked && nofBits(LS_GetVal()) <= 15) { /* light received from the other side? */
#if 0
      byte res;
    
      TI2_Disable(); /* disable RTOS during communication not to interrupt communication (time sensitive) */
      LED_Red_Off();
      LED_Green_Off();
      rx.data[0] = '\0';
      res = LC_EnableRequest((void*)0, &rx, 1); /* receive key */
      TI2_Enable(); /* enable RTOS again */
      if (res == ERR_OK) { /* communication successful! */
        if (rxbuf[0] == 'a') { /* rx mode, and we have the right key */
          StartSounder(900);
          //break; /* return */
        } else { /* error :-( */
          /* retry */
        }
      }
#else
      locked = FALSE;
      StartSounder(900);
#endif
    }
    TI1_Enable(); /* display refresh */
  }
  uCOS1_OSTaskResume(TASK_PRIO_BLINK);
}
/* -------- UnlockDoor ----------------- */
static void UnlockDoor(void) {
#if 1
  byte i, err;

  TI1_Disable(); /* disable display display refresh during communication */
  TI2_Disable(); /* disable RTOS during communication not to interrupt communication (time sensitive) */
  for(i=0;i<30;i++) {
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&0x80) { /* electrode 8: quit */
      break; /* return */
    }
    LS_On();                             /* turn on LEDs to start IDLE cycle with a MARK */
    WAIT1_Waitms(200);            /* have light turned on for MARK */
    LS_Off();                            /* turn off LED */
    WAIT1_Waitms(200);            /* have light turned on for MARK */
  }
  TI2_Enable(); /* enable RTOS again */
  TI1_Enable(); /* display refresh */

#else
  byte res;
  byte err;
  const unsigned char key[]="a"; /* the key we use */


  LedFont_ScrollText("Unlock", TRUE, TRUE);
  /* initialize communication data */
  tx.data = (byte *)&key[0];
  tx.nofBytes = 1; /* only one byte key */
  LEDM1_Off();
  TI1_Disable(); /* disable display display refresh during communication */
  for(;;) {
    LED_Red_Neg();
    LED_Green_Neg();
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&0x80) { /* electrode 8: quit */
      break; /* return */
    }
    (void)uCOS1_OSTimeDlyHMSM(0,0,0,10);
    /* send key */
    TI2_Disable(); /* disable RTOS during communication not to interrupt communication (time sensitive) */
    LED_Red_Off();
    LED_Green_Off();
    /* send key */
    res = LC_EnableRequest(&tx, (void*)0, 1);
    TI2_Enable(); /* enable RTOS again */
    if (res == ERR_OK) { /* communication successful! */
      StartSounder(300);
      break; /* return */
    } else { /* error :-( */
      /* retry */
    }
  } /* for */
  TI1_Enable(); /* display refresh */
  LED_Red_Off();
  LED_Green_Off();
#endif
}
/* -------- Buttons ----------------- */
static void Buttons(void *pdata) {
  (void)pdata; /* avoid compiler warning */
  for(;;) {
#if MPR08x1_INTERRUPTS_ENABLED == 0
    MPR08x1_ProcessTouch();
#endif
    (void)uCOS1_OSTimeDlyHMSM(0,0,0,50); /* wait for 50 ms */
  }
}
/* -------- Blink ----------------- */
static void Blink(void *pdata) {
  (void)pdata; /* avoid compiler warning */
  for(;;) {
    if (LiIon1_isPowerPresent()) { /* USB cable plugged in */
      if (LiIon1_isCharging()) {
        LED_Red_On();
        (void)uCOS1_OSTimeDlyHMSM(0,0,0,250); /* wait for 0.25 second */
        LED_Red_Off();
        (void)uCOS1_OSTimeDlyHMSM(0,0,0,250); /* wait for 0.25 second */
      } else { /* plugged in, and not charging/battery full */
      LED_Red_On(); /* blink LED every seconds */
      (void)uCOS1_OSTimeDlyHMSM(0,0,2,0); /* wait for 1 second */
      LED_Red_Off(); /* blink LED every seconds */
      (void)uCOS1_OSTimeDlyHMSM(0,0,2,0); /* wait for 1 second */
      }
    } else {
      LED_Green_On(); /* blink LED every seconds */
      (void)uCOS1_OSTimeDlyHMSM(0,0,2,0); /* wait for 1 second */
      LED_Green_Off(); /* blink LED every seconds */
      (void)uCOS1_OSTimeDlyHMSM(0,0,2,0); /* wait for 1 second */
    }
  } /* forever */
}
/* -------- LightDemo ----------------- */
static void LightDemo(void) {
  INT8U err;
  unsigned char i = 0;
  LEDM1_SensorValType val;
  word threshold = 0;
  
  LedFont_ScrollText("Light!", TRUE, TRUE);
  threshold = 0;
  for(;;) {
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&0x80) { /* electrode 8: quit */
      uCOS1_OSFlagPost(ButtonStatus, 0xFF, OS_FLAG_CLR, &err); /* clear all button flags */
      GDisp1_Clear();
      return;
    }
    LEDM1_Off(); /* clear display */
    TI1_Disable(); /* disable display display refresh during communication */
    TI2_Disable(); /* disable RTOS during communication not to interrupt communication (time sensitive) */
    if (threshold==0) { /* threshold not defined yet */
      if (LS_FindThreshold(&threshold)!=ERR_OK) {
        threshold = 1000; /* use a default one in error case */
      } else { /* set threshold 20% above clipping level */
        threshold += threshold/5;
      }
    }
    val = LS_GetLightVal((word)(LS_THRESHOLD_STEP_US*threshold));
    TI2_Enable(); /* re-enable RTOS interrupts */
    TI1_Enable(); /* re-enable display again */
    i = 0;
    GDisp1_Clear(); /* clear display */
    while(val != 0) { /* draw bars for every bit: a zero bit means light seen */
      if (val&1) {
        GDisp1_DrawVLine(i, 0, GDisp1_GetHeight(), GDisp1_COLOR_BLACK);
      }
      val >>= 1; /* next bit */
      i++;
    }
    LEDM1_UpdateFull(); /* refresh display */
    (void)uCOS1_OSTimeDlyHMSM(0,0,0,150); /* wait some time */
  }
}
/* -------- Main Task ----------------- */
static void ExitPressed(void) {
  byte i;
  INT8U err;

  uCOS1_OSFlagPost(ButtonStatus, 0xFF, OS_FLAG_CLR, &err); /* clear all button flags */
  uCOS1_OSFlagPost(LedFont_Flags, LEDFONT_FLAG_QUIT, OS_FLAG_CLR, &err); /* clear flag otherwise Led scrolling will stop as well */
  LedFont_ScrollText("", TRUE, TRUE); /* clear scrolling text */
  for(i=0;i<GDisp1_GetHeight();i++) {
    GDisp1_DrawFilledBox((GDisp1_PixelDim)(0+i),i,(GDisp1_PixelDim)(GDisp1_GetWidth()-2*i), 1, GDisp1_COLOR_BLACK);
    (void)uCOS1_OSTimeDlyHMSM(0,0,0,100);
  }
  GDisp1_UpdateFull();
}

static void MainTask(void *pdata) {
  INT8U err;

  (void)pdata; /* avoid compiler warning */
  LedFont_ScrollText("E1-E7: Demos, E8: Quit", FALSE, FALSE);
  for(;;) {
#if PL_HAS_ACCEL_GAME
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&(1<<0)) { /* electrode 1 */
      uCOS1_OSFlagPost(ButtonStatus, (1<<0), OS_FLAG_CLR, &err); /* clear flag */
      ExitPressed();
      AccelGame();
      ExitPressed();
    }
#endif
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&(1<<1)) { /* electrode 2 */
      uCOS1_OSFlagPost(ButtonStatus, (1<<1), OS_FLAG_CLR, &err); /* clear flag */
      ExitPressed();
      MoveX();
      ExitPressed();
    }
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&(1<<2)) { /* electrode 3 */
      uCOS1_OSFlagPost(ButtonStatus, (1<<2), OS_FLAG_CLR, &err); /* clear flag */
      ExitPressed();
      LightComm(NULL); /* receive */
      ExitPressed();
    }
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&(1<<3)) { /* electrode 4 */
      uCOS1_OSFlagPost(ButtonStatus, (1<<3), OS_FLAG_CLR, &err); /* clear flag */
      ExitPressed();
      LightComm("a"); /* send */
      ExitPressed();
    }
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&(1<<4)) { /* electrode 5 */
      uCOS1_OSFlagPost(ButtonStatus, (1<<4), OS_FLAG_CLR, &err); /* clear flag */
      ExitPressed();
      LightDemo();
      ExitPressed();
    }
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&(1<<5)) { /* electrode 6: lock door */
      uCOS1_OSFlagPost(ButtonStatus, (1<<5), OS_FLAG_CLR, &err); /* clear flag */
      ExitPressed();
      LockDoor();
      ExitPressed();
    }
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&(1<<6)) { /* electrode 7: unlock door */
      uCOS1_OSFlagPost(ButtonStatus, (1<<6), OS_FLAG_CLR, &err); /* clear flag */
      ExitPressed();
      UnlockDoor();
      ExitPressed();
    }
    if (uCOS1_OSFlagQuery(ButtonStatus, &err)&(1<<6)) { /* electrode 8: quit */
      ExitPressed();
    }
    (void)uCOS1_OSTimeDlyHMSM(0,0,0,100); /* wait for some time and give scheduler a chance */
  }
}
/* ------------------ RTOS -------------------------- */
static void InitTask(void *pdata) {
  (void)pdata; /* avoid compiler warning */
  uCOS1_OSTimerInit(); /* start timer ticks in first task */
  (void)uCOS1_OSTaskCreate(Blink, (void*)0, (void*)&BlinkStk[TASK_STK_SIZE-1], TASK_PRIO_BLINK);
#if PL_HAS_ACCEL_GAME
  (void)uCOS1_OSTaskCreate(MainTask, (void*)0, (void*)&MainTaskStk[TASK_STK_SIZE-1], TASK_PRIO_MAIN);
#endif
  (void)uCOS1_OSTaskCreate(Buttons, (void*)0, (void*)&ButtonsTaskStk[TASK_STK_SIZE-1], TASK_PRIO_BUTTONS);
  (void)uCOS1_OSTaskCreate(Sounder, (void*)0, (void*)&SounderTaskStk[TASK_STK_SIZE-1], TASK_PRIO_SOUNDER);
  (void)uCOS1_OSTaskCreate(LedFont_Scroller, (void*)0, (void*)&ScrollerTaskStk[TASK_STK_SIZE-1], TASK_PRIO_SCROLLER);
  (void)uCOS1_OSTaskDel(TASK_PRIO_INIT);  /* delete init task */
}

void OS_Run(void) {
  INT8U err;
  
  uCOS1_OSInit();
  ButtonStatus = uCOS1_OSFlagCreate(0, &err);
  LedFont_Flags = uCOS1_OSFlagCreate(0, &err);
  uCOS1_OSTaskCreate(InitTask, (void*)0, (void*)&InitTaskStk[TASK_STK_SIZE-1], TASK_PRIO_INIT);
  uCOS1_OSStart();
}

word delay = 3000; /* 0: 3000, 1: 10000 */
word rrow = 2;
/* ------------------ main -------------------------- */
byte GetBit(byte row) {

  if (row==0) {
    PTEDD_PTEDD0 = 1; /* cathode output */
    PTED_PTED0 = 1;   /* put 1 */

    PTADD_PTADD0 = 1; /* anode ouput */
    PTADD_PTADD1 = 1; /* anode ouput */
    PTADD_PTADD2 = 1; /* anode ouput */
    PTADD_PTADD3 = 1; /* anode ouput */
    PTADD_PTADD4 = 1; /* anode ouput */
    
    /* anode low */
    PTAD_PTAD0 = 0;
    PTAD_PTAD1 = 0;
    PTAD_PTAD2 = 0;
    PTAD_PTAD3 = 0;
    PTAD_PTAD4 = 0;

    PTEDD_PTEDD0 = 0; /* input */
    WAIT1_Waitus(delay);       /* lower value means more light is needed to get discharge to zero */
    return PTED_PTED0;
  
  } else if (row == 1) {
    PTEDD_PTEDD0 = 1; /* cathode output */
    PTED_PTED0 = 1;   /* put 1 */

    PTADD_PTADD0 = 1; /* anode ouput */
    PTADD_PTADD1 = 1; /* anode ouput */
    PTADD_PTADD2 = 1; /* anode ouput */
    PTADD_PTADD3 = 1; /* anode ouput */
    PTADD_PTADD4 = 1; /* anode ouput */

    /* anode low or high */
    PTAD_PTAD0 = 0;
    PTAD_PTAD1 = 0;
    PTAD_PTAD2 = 0;
    PTAD_PTAD3 = 0;
    PTAD_PTAD4 = 0;

    PTADD_PTADD0 = 0; /* anode input */
    PTADD_PTADD1 = 0; /* anode ouput */
    PTADD_PTADD2 = 0; /* anode input */
    PTADD_PTADD3 = 0; /* anode input */
    PTADD_PTADD4 = 0; /* anode input */

    WAIT1_Waitus(delay);       /* lower value means more light is needed to get discharge to zero */
    return (byte)(PTAD&0x1F);
  } else if (row == 2) {
    PTEDD_PTEDD0 = 1; /* cathode output */
    PTED_PTED0 = 1;   /* put 1 */

    PTADD_PTADD0 = 1; /* anode ouput */
    PTADD_PTADD1 = 1; /* anode ouput */
    PTADD_PTADD2 = 1; /* anode ouput */
    PTADD_PTADD3 = 1; /* anode ouput */
    PTADD_PTADD4 = 1; /* anode ouput */

    /* anode low or high */
    PTAD_PTAD0 = 0;
    PTAD_PTAD1 = 0;
    PTAD_PTAD2 = 0;
    PTAD_PTAD3 = 0;
    PTAD_PTAD4 = 0;

    //PTADD_PTADD0 = 0; /* anode input */
    //PTADD_PTADD1 = 0; /* anode ouput */
    PTADD_PTADD2 = 0; /* anode input */
    //PTADD_PTADD3 = 0; /* anode input */
    //PTADD_PTADD4 = 0; /* anode input */

    WAIT1_Waitus(delay);       /* lower value means more light is needed to get discharge to zero */
    return (PTAD_PTAD2);
  }
}

byte ValVal;

void main(void) {
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* help:
     Blink Task:
     - Red LED flashing once a second: USB cable plugged in, fully charged
     - Red LED flashing twice a second: USB cable plugged in, charging.
     - Green LED flashing once a second: running on batteries
     Main Tas:
     - E1: Accel Game (E8 quit)
     - E2: Moves a dot on first line (MoveX) (E8 quit)
     - E3: receive a message
     - E4: send a message
     - E5: Light-Finger Demo
     - E6: Lock Door
     - E7: Unlock Door
  */
#if 0
  PTA5_SetVal(); /* enable charge pump for display */
  OLED1_Init();
#endif

#if 0
  Cpu_DisableInt();
  for(;;) {
    ValVal = GetBit(rrow);
    if (ValVal) {
      LED_Red_On();
      LED_Green_Off();
    } else {
      LED_Red_Off();
      LED_Green_On();
    }
  }
#endif  
  OS_Run();

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/


/* END BadgeBoard */
/*
** ###################################################################
**
**     This file was created by UNIS Processor Expert 3.03 [04.07]
**     for the Freescale ColdFireV1 series of microcontrollers.
**
** ###################################################################
*/
