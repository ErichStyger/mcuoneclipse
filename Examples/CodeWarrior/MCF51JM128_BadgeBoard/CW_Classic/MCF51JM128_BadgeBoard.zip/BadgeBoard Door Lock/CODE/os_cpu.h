/*
*********************************************************************************************************
*                                               uC/OS-II
*                                        The Real-Time Kernel
*
*                              (c) Copyright 2008, Micrium, Inc, Weston, FL
*                                          All Rights Reserved
*
*                                    Processor CPU Specific code
*
* File  : OS_CPU.H
* By    : Erich Styger, generated with Processor Expert for CodeWarrior, based on Jean J. Labrosse
*********************************************************************************************************
*/

#ifndef OS_CPU_H
#define OS_CPU_H

/*
*********************************************************************************************************
*                                              DATA TYPES
*********************************************************************************************************
*/
#ifdef  OS_CPU_GLOBALS
  #define OS_CPU_EXT
#else
  #define OS_CPU_EXT  extern
#endif

typedef unsigned char  BOOLEAN;              /* boolean entity */
typedef unsigned char  INT8U;                /* unsigned 8bit entity */
typedef signed   char  INT8S;                /* signed 8bit entity */
typedef unsigned short INT16U;               /* unsigned 16bit entity */
typedef signed   short INT16S;               /* signed 16bit entity */
typedef unsigned long  INT32U;               /* unsigned 32bit entity */
typedef signed   long  INT32S;               /* signed 32bit entity */
typedef float          FP32;                 /* single precision floating point entity */
typedef double         FP64;                 /* double precision floating point entity */

typedef INT32U OS_STK;                       /* each stack entry is a 32bit value */
typedef INT16U OS_CPU_SR;                    /* size of CPU status register is 16bit */

/* ColdFire specific support */
#define  OS_INITIAL_SR        0x2000         /* Supervisor mode, interrupts enabled */
#define  OS_TRAP_NBR          14             /* OSCtxSw() invoked through TRAP #14 */

#if 0
#define BYTE    INT8S                        /* Define data types for backward compatibility ...   */
#define UBYTE   INT8U                        /* ... to uC/OS V1.xx                                 */
#define WORD    INT16S
#define UWORD   INT16U
#define LONG    INT32S
#define ULONG   INT32U
#endif

/*
* Method #1:  Disable/Enable interrupts using simple instructions.  After critical section, interrupts
*             will be enabled even if they were disabled before entering the critical section.
*
* Method #2:  Disable/Enable interrupts by preserving the state of interrupts.  In other words, if
*             interrupts were disabled before entering the critical section, they will be disabled when
*             leaving the critical section.
*
* Method #3:  Disable/Enable interrupts by preserving the state of interrupts.  Generally speaking you
*             would store the state of the interrupt disable flag in the local variable 'cpu_sr' and then
*             disable interrupts.  'cpu_sr' is allocated in all of uC/OS-II's functions that need to
*             disable interrupts.  You would restore the interrupt disable state by copying back 'cpu_sr'
*             into the CPU's status register.
*/
#define OS_CRITICAL_METHOD    3              /* specifies the methode we are using to enter a critcal section */

#if OS_CRITICAL_METHOD == 1
  #error "OS_CRITICAL_METHOD #1 - Not Implemented"
#endif

#if OS_CRITICAL_METHOD == 2
  #error "OS_CRITICAL_METHOD #2 - Not Implemented"
#endif

#if OS_CRITICAL_METHOD == 3
  #define OS_ENTER_CRITICAL()  (cpu_sr = OS_CPU_SR_Save()) /* Disable interrupts */
  #define OS_EXIT_CRITICAL()   (OS_CPU_SR_Restore(cpu_sr)) /* Enable  interrupts */
#endif

#define OS_STK_GROWTH    1                   /* Define stack growth: 1 = Down, 0 = Up  */
#define OS_TASK_SW()     asm(TRAP #14;)      /* Use Trap #14 to perform a Task Level Context Switch */

/*
** ===================================================================
**     Method      :  uCOS1_OSStartHighRdy (component uCOS_II)
**
**     Description :
**         This function is called by OSStart() to start the highest 
**         priority task that was created by your application before 
**         calling OSStart().
**         This method is internal. It is used by Processor Expert only.
** ===================================================================
*/

/*
** ===================================================================
**     Method      :  uCOS1_OSCtxSw (component uCOS_II)
**
**     Description :
**         This function is called when a task makes a higher priority 
**         task ready-to-run.
**         This method is internal. It is used by Processor Expert only.
** ===================================================================
*/

/*
** ===================================================================
**     Method      :  uCOS1_OSIntCtxSw (component uCOS_II)
**
**     Description :
**         This function is called by OSIntExit() to perform a context 
**         switch to a task that has been made ready-to-run by an ISR.
**         This method is internal. It is used by Processor Expert only.
** ===================================================================
*/

OS_CPU_SR __declspec(register_abi) OS_CPU_SR_Save(void);
/*
** ===================================================================
**     Method      :  uCOS1_OS_CPU_SR_Save (component uCOS_II)
**
**     Description :
**         These function implements OS_CRITICAL_METHOD #3.
**         This method is internal. It is used by Processor Expert only.
** ===================================================================
*/

void __declspec(register_abi) OS_CPU_SR_Restore(OS_CPU_SR sr);
/*
** ===================================================================
**     Method      :  uCOS1_OS_CPU_SR_Restore (component uCOS_II)
**
**     Description :
**         These function implements OS_CRITICAL_METHOD #3.
**         This method is internal. It is used by Processor Expert only.
** ===================================================================
*/


/* map the uCOS-II hooks into bean event */
#if OS_TIME_TICK_HOOK_EN
  #define OSTimeTickHook   uCOS1_OSTimeTickHook
#endif /* OS_TIME_TICK_HOOK_EN */








#if OS_TASK_SW_HOOK_EN
  #define OSTaskSwHook uCOS1_OSTaskSwHook
#endif /* OS_TASK_SW_HOOK_EN */

void          OSStartHighRdy          (void);
void          OSIntCtxSw              (void);
void          OSCtxSw                 (void);


#endif /* OS_CPU_H */
