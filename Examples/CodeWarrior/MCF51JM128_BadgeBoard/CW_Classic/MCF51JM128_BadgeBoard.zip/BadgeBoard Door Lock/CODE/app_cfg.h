#ifndef _APP_CONFIG_H
#define _APP_CONFIG_H

#if defined(__MWERKS__) && defined(__HIWARE__) /* Metrowerks compiler specific pragmas */
  /* some compiler warning settings to avoid warnings in uCOS-II code: */
  #pragma MESSAGE DISABLE C1420 /* result of function-call is ignored */
  #pragma MESSAGE DISABLE C2705 /* possible loss of data */
  #pragma MESSAGE DISABLE C5917 /* removed dead code */
  #pragma MESSAGE DISABLE C5660 /* removed dead code */
  #pragma MESSAGE DISABLE C5905 /* multiplication with one */
#endif

#endif _APP_CONFIG_H
