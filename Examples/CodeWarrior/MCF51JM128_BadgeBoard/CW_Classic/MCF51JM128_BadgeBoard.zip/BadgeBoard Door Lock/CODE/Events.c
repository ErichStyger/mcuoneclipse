/** ###################################################################
**     Filename  : Events.C
**     Project   : BadgeBoard
**     Processor : MCF51JM128VLK
**     Beantype  : Events
**     Version   : Driver 01.02
**     Compiler  : CodeWarrior ColdFireV1 C Compiler
**     Date/Time : 11.01.2009, 16:54
**     Abstract  :
**         This is user's event module.
**         Put your event handler code here.
**     Settings  :
**     Contents  :
**         LC_OnStatus            - void LC_OnStatus(byte status);
**         LC_OnData              - void LC_OnData(LC_tTxRxDesc *data);
**         uCOS1_OSTimeTickHook   - void uCOS1_OSTimeTickHook(void);
**         uCOS1_OSTaskStatHook   - void uCOS1_OSTaskStatHook(void);
**         uCOS1_OSTaskIdleHook   - void uCOS1_OSTaskIdleHook(void);
**         uCOS1_OSTCBInitHook    - void uCOS1_OSTCBInitHook(OS_TCB *ptcb);
**         uCOS1_OSTaskDelHook    - void uCOS1_OSTaskDelHook(OS_TCB *ptcb);
**         uCOS1_OSTaskCreateHook - void uCOS1_OSTaskCreateHook(OS_TCB *ptcb);
**         uCOS1_OSInitHookBegin  - void uCOS1_OSInitHookBegin(void);
**         uCOS1_OSInitHookEnd    - void uCOS1_OSInitHookEnd(void);
**         MPR08x1_OnPress        - void MPR08x1_OnPress(byte button);
**         MPR08x1_OnFault        - void MPR08x1_OnFault(byte reason);
**         TI1_OnInterrupt        - void TI1_OnInterrupt(void);
**
**     (c) Copyright UNIS, a.s. 1997-2008
**     UNIS, a.s.
**     Jundrovska 33
**     624 00 Brno
**     Czech Republic
**     http      : www.processorexpert.com
**     mail      : info@processorexpert.com
** ###################################################################*/
/* MODULE Events */

#include "Cpu.h"
#include "Events.h"
#include "uCOS1.h"

/*
** ===================================================================
**     Event       :  LC_OnStatus (module Events)
**
**     From bean   :  LC [LightComm]
**     Description :
**         Event is called on communiation status change
**     Parameters  :
**         NAME            - DESCRIPTION
**         status          - 
**     Returns     : Nothing
** ===================================================================
*/
void LC_OnStatus(byte status)
{
  switch(status) {
    case LC_STATUS_NONE:
      break;
    case LC_STATUS_IDLE:
      break;
    case LC_STATUS_TXRX:
      break;
    case LC_STATUS_TX_START:
    case LC_STATUS_RX_START:
      break;
    case LC_STATUS_TX_STOP:
    case LC_STATUS_RX_STOP:
      break;
    case LC_STATUS_TX_BIT_1:
    case LC_STATUS_RX_BIT_1:
      LED_Red_Neg();
      break;
    case LC_STATUS_TX_BIT_0:
    case LC_STATUS_RX_BIT_0:
      LED_Red_Neg();
      break;
  }
}

/*
** ===================================================================
**     Event       :  LC_OnData (module Events)
**
**     From bean   :  LC [LightComm]
**     Description :
**         Event called on the event we received a data packet.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * data            - Pointer to a descriptor for the data we
**                           received.
**     Returns     : Nothing
** ===================================================================
*/
void LC_OnData(LC_tTxRxDesc *data)
{
  if (data->nofBytes == 2 && data->data[0] == 'a') {
    LED_Green_Neg();
  }
}

/*
** ===================================================================
**     Event       :  MPR08x1_OnPress (module Events)
**
**     From bean   :  MPR08x1 [MPR08x]
**     Description :
**         Event for a button pressed. You can disable this event if
**         you are not interested in it in order to save code size.
**     Parameters  :
**         NAME            - DESCRIPTION
**         button          - Button number, in the range 0 to 7.
**     Returns     : Nothing
** ===================================================================
*/
#include "LedFont.h"
void MPR08x1_OnPress(byte button)
{
  extern OS_FLAG_GRP *ButtonStatus;
  INT8U err;
  
  uCOS1_OSFlagPost(ButtonStatus, (OS_FLAGS)(1<<button), OS_FLAG_SET, &err);
  if (button==7) { /* electrode 8 */
    OSFlagPost(LedFont_Flags, LEDFONT_FLAG_QUIT, OS_FLAG_SET, &err); /* Set quit flag */
  }
}

/*
** ===================================================================
**     Event       :  MPR08x1_OnFault (module Events)
**
**     From bean   :  MPR08x1 [MPR08x]
**     Description :
**         This event is called in case of a fault sensor condition.
**         You can disable this event if you are not interested in it
**         in order to save code size.
**     Parameters  :
**         NAME            - DESCRIPTION
**         reason          - reason of fault: 1 for short to VSS
**                           detected, 2 for short to VDD detected, 3
**                           for FIFO overflow (see ON_MPR083_FAULT_xxx
**                           defines).
**     Returns     : Nothing
** ===================================================================
*/
void MPR08x1_OnFault(byte reason)
{
  (void)reason;
  while (1) {
    LED_Red_Neg();
    WAIT1_Waitms(100);
    if (reason == ON_MPR08x_I2C_MAX_KEYS_ERROR) return;
  }
}

/*
** ===================================================================
**     Event       :  TI1_OnInterrupt (module Events)
**
**     From bean   :  TI1 [TimerInt]
**     Description :
**         When a timer interrupt occurs this event is called (only
**         when the bean is enabled - <Enable> and the events are
**         enabled - <EnableEvent>). This event is enabled only if a
**         <interrupt service/event> is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void TI1_OnInterrupt(void)
{
  LEDM1_UpdateFull(); /* refresh display */
}

/*
** ===================================================================
**     Event       :  uCOS1_OSTaskSwHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called when a task switch is performed.
**         This allows you to perform other operations during a context
**         switch. Notes: 1) Interrupts are disabled during this call.
**         2) It is assumed that the global pointer 'OSTCBHighRdy'
**         points to the TCB of the task that will be 'switched in' (i.
**         e. the highest priority task) and, 'OSTCBCur' points to the
**         task being switched out (i.e. the preempted task).
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void uCOS1_OSTaskSwHook(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  uCOS1_OSTimeTickHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called when a time tick event occurs. This
**         allows you to perform other operations during a time tick.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void uCOS1_OSTimeTickHook(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  uCOS1_OSTCBInitHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called on initialization of a task control
**         block.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * ptcb            - ptcp is a pointer to the task control
**                           block of the task being initialized.
**     Returns     : Nothing
** ===================================================================
*/
void uCOS1_OSTCBInitHook(OS_TCB *ptcb)
{
  (void)ptcb; /* to avoid compiler warning */
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  uCOS1_OSTaskDelHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called when a task is deleted. Note(s) : 1)
**         Interrupts are enabled during this call.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * ptcb            - ptcp is a pointer to the task control
**                           block of the task being deleted.
**     Returns     : Nothing
** ===================================================================
*/
void uCOS1_OSTaskDelHook(OS_TCB *ptcb)
{
  (void)ptcb; /* to avoid compiler warning */
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  uCOS1_OSTaskCreateHook (module Events)
**
**     From bean   :  uCOS1 [uCOS_II]
**     Description :
**         This function is called when a task is created. Note(s) : 1)
**         Interrupts are enabled during this call.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * ptcb            - ptcp is a pointer to the task control
**                           block of the task being deleted.
**     Returns     : Nothing
** ===================================================================
*/
void uCOS1_OSTaskCreateHook(OS_TCB *ptcb)
{
  (void)ptcb; /* to avoid compiler warning */
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  ACCEL1_OnADGet (module Events)
**
**     Component   :  ACCEL1 [MMA7260Q]
**     Description :
**         Called to get mutual access to the A/D converter
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void ACCEL1_OnADGet(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  ACCEL1_OnADGive (module Events)
**
**     Component   :  ACCEL1 [MMA7260Q]
**     Description :
**         Called to give back mutual access to the A/D converter
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void ACCEL1_OnADGive(void)
{
  /* Write your code here ... */
}

/* END Events */

/*
** ###################################################################
**
**     This file was created by UNIS Processor Expert 3.03 [04.07]
**     for the Freescale ColdFireV1 series of microcontrollers.
**
** ###################################################################
*/
