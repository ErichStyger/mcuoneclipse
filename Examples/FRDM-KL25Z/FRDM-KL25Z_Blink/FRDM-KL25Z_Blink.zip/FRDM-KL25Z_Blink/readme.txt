readme.txt
----------
this project is a make file project. It is for the FRDM-KL25Z and blinks the RED LED on the board.