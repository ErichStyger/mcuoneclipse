readme.txt
----------

This project implements a demo program for the FRDM-KL26Z board.

See
http://mcuoneclipse.com/2013/12/29/review-new-frdm-kl26z-board/