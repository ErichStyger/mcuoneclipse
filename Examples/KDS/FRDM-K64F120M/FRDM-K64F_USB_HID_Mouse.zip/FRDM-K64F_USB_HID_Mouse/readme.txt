readme.txt
----------

This project implements USB HID Mouse for the FRDM-K64F board, using Processor Expert and Kinetis Design Studio.