#ifndef __DERIVATIVE_USB
#define __DERIVATIVE_USB

/* Include the derivative-specific header file */
#if 0 /* << EST */
  #include <MK60N512VMD100.h>
#else
  #include "Cpu.h"
#endif

#define __MK_xxx_H__

#endif

