/**
 * \file
 * \brief Configuration header file for SDK_BitIO
 *
 * This header file is used to configure settings of the SDK Bit I/O module.
 */
#ifndef __RX_RDY_CONFIG_H
#define __RX_RDY_CONFIG_H

#if MCUC1_CONFIG_SDK_VERSION_USED == MCUC1_CONFIG_SDK_MCUXPRESSO_2_0
  #include "pin_mux.h" /* include pin muxing header file */

  #if defined(BOARD_INITPINS_RX_RDY_PIN)
    #define RX_RDY_CONFIG_PIN_NUMBER    BOARD_INITPINS_RX_RDY_PIN
  #endif
  #if defined(BOARD_INITPINS_RX_RDY_GPIO)
    #define RX_RDY_CONFIG_GPIO_NAME     BOARD_INITPINS_RX_RDY_GPIO
  #endif
  #if defined(BOARD_INITPINS_RX_RDY_PORT)
    #define RX_RDY_CONFIG_PORT_NAME     BOARD_INITPINS_RX_RDY_PORT
  #endif
#endif


#ifndef RX_RDY_CONFIG_PORT_NAME
  #if MCUC1_CONFIG_CPU_IS_IMXRT
    #define RX_RDY_CONFIG_PORT_NAME       GPIO1
  #elif MCUC1_CONFIG_CPU_IS_LPC
    #define RX_RDY_CONFIG_PORT_NAME       0
  #else /* name from properties */
    #define RX_RDY_CONFIG_PORT_NAME       PORTA
  #endif
    /*!< name of PORT, is pointer to PORT_Type */
#endif

#ifndef RX_RDY_CONFIG_GPIO_NAME
  #if MCUC1_CONFIG_CPU_IS_IMXRT
    #define RX_RDY_CONFIG_GPIO_NAME       GPIO1
  #elif MCUC1_CONFIG_CPU_IS_LPC
    #define RX_RDY_CONFIG_GPIO_NAME       GPIO
  #else /* name from properties */
    #define RX_RDY_CONFIG_GPIO_NAME       GPIOA
  #endif
    /*!< name of GPIO, is pointer to GPIO_Type, not used for S32K SDK */
#endif

#ifndef RX_RDY_CONFIG_PIN_NUMBER
  #define RX_RDY_CONFIG_PIN_NUMBER      9u
    /*!< number of pin, type unsigned integer */
#endif

#ifndef RX_RDY_CONFIG_PIN_SYMBOL
  #define RX_RDY_CONFIG_PIN_SYMBOL      RX_RDY
    /*!< symbolic name for pin, used for NXP SDK V1.3 */
#endif

#ifndef RX_RDY_CONFIG_INIT_PIN_VALUE
  #define RX_RDY_CONFIG_INIT_PIN_VALUE  0
  /*!< 0: Pin data is initialized with 0 (low); 1: pin value is initialized with 1 (high) */
#endif

/* different types of pin direction settings */
#define RX_RDY_CONFIG_INIT_PIN_DIRECTION_NONE    (0)
#define RX_RDY_CONFIG_INIT_PIN_DIRECTION_INPUT   (1)
#define RX_RDY_CONFIG_INIT_PIN_DIRECTION_OUTPUT  (2)

#ifndef RX_RDY_CONFIG_INIT_PIN_DIRECTION
  #define RX_RDY_CONFIG_INIT_PIN_DIRECTION  RX_RDY_CONFIG_INIT_PIN_DIRECTION_INPUT
#endif

#ifndef RX_RDY_CONFIG_DO_PIN_MUXING
  #define RX_RDY_CONFIG_DO_PIN_MUXING  0
  /*!< 1: perform pin muxing in Init(), 0: do not do pin muxing */
#endif

#ifndef RX_RDY_CONFIG_PULL_RESISTOR
  #define RX_RDY_CONFIG_PULL_RESISTOR  1
  /*!< pull resistor setting. 0: no pull resistor, 1: pull-up, 2: pull-down, 3: pull-up or no pull, 4: pull-down or no pull: 4: autoselect-pull */
#endif

#endif /* __RX_RDY_CONFIG_H */
