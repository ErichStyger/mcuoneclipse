/**
 * \file
 * \brief Configuration header file for SDK_BitIO
 *
 * This header file is used to configure settings of the SDK Bit I/O module.
 */
#ifndef __SW3_CONFIG_H
#define __SW3_CONFIG_H

#if MCUC1_CONFIG_SDK_VERSION_USED == MCUC1_CONFIG_SDK_MCUXPRESSO_2_0
  #include "pin_mux.h" /* include pin muxing header file */

  #if defined(BOARD_INITPINS_SW3_PIN)
    #define SW3_CONFIG_PIN_NUMBER    BOARD_INITPINS_SW3_PIN
  #endif
  #if defined(BOARD_INITPINS_SW3_GPIO)
    #define SW3_CONFIG_GPIO_NAME     BOARD_INITPINS_SW3_GPIO
  #endif
  #if defined(BOARD_INITPINS_SW3_PORT)
    #define SW3_CONFIG_PORT_NAME     BOARD_INITPINS_SW3_PORT
  #endif
#endif


#ifndef SW3_CONFIG_PORT_NAME
  #if MCUC1_CONFIG_CPU_IS_IMXRT
    #define SW3_CONFIG_PORT_NAME       GPIO1
  #elif MCUC1_CONFIG_CPU_IS_LPC
    #define SW3_CONFIG_PORT_NAME       0
  #else /* name from properties */
    #define SW3_CONFIG_PORT_NAME       PORTB
  #endif
    /*!< name of PORT, is pointer to PORT_Type */
#endif

#ifndef SW3_CONFIG_GPIO_NAME
  #if MCUC1_CONFIG_CPU_IS_IMXRT
    #define SW3_CONFIG_GPIO_NAME       GPIO1
  #elif MCUC1_CONFIG_CPU_IS_LPC
    #define SW3_CONFIG_GPIO_NAME       GPIO
  #else /* name from properties */
    #define SW3_CONFIG_GPIO_NAME       GPIOB
  #endif
    /*!< name of GPIO, is pointer to GPIO_Type, not used for S32K SDK */
#endif

#ifndef SW3_CONFIG_PIN_NUMBER
  #define SW3_CONFIG_PIN_NUMBER      5u
    /*!< number of pin, type unsigned integer */
#endif

#ifndef SW3_CONFIG_PIN_SYMBOL
  #define SW3_CONFIG_PIN_SYMBOL      SW_NMI
    /*!< symbolic name for pin, used for NXP SDK V1.3 */
#endif

#ifndef SW3_CONFIG_INIT_PIN_VALUE
  #define SW3_CONFIG_INIT_PIN_VALUE  0
  /*!< 0: Pin data is initialized with 0 (low); 1: pin value is initialized with 1 (high) */
#endif

/* different types of pin direction settings */
#define SW3_CONFIG_INIT_PIN_DIRECTION_NONE    (0)
#define SW3_CONFIG_INIT_PIN_DIRECTION_INPUT   (1)
#define SW3_CONFIG_INIT_PIN_DIRECTION_OUTPUT  (2)

#ifndef SW3_CONFIG_INIT_PIN_DIRECTION
  #define SW3_CONFIG_INIT_PIN_DIRECTION  SW3_CONFIG_INIT_PIN_DIRECTION_INPUT
#endif

#ifndef SW3_CONFIG_DO_PIN_MUXING
  #define SW3_CONFIG_DO_PIN_MUXING  0
  /*!< 1: perform pin muxing in Init(), 0: do not do pin muxing */
#endif

#ifndef SW3_CONFIG_PULL_RESISTOR
  #define SW3_CONFIG_PULL_RESISTOR  0
  /*!< pull resistor setting. 0: no pull resistor, 1: pull-up, 2: pull-down, 3: pull-up or no pull, 4: pull-down or no pull: 4: autoselect-pull */
#endif

#endif /* __SW3_CONFIG_H */
