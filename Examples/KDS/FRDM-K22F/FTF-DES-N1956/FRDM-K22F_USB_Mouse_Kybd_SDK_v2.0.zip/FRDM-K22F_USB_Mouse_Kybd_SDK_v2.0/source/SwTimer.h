/*
 * SwTimer.h
 *
 *  Created on: 05.05.2016
 *      Author: Erich Styger
 */

#ifndef SOURCE_SWTIMER_H_
#define SOURCE_SWTIMER_H_


void SWT_Init(void);


#endif /* SOURCE_SWTIMER_H_ */
