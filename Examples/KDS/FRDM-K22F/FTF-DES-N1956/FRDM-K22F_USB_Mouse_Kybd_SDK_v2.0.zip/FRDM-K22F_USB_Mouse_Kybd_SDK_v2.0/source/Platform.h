/*
 * Platform.h
 *
 *  Created on: 10.05.2016
 *      Author: Erich Styger
 */

#ifndef SOURCE_PLATFORM_H_
#define SOURCE_PLATFORM_H_


#define PL_CONFIG_HAS_SHELL_QUEUE    (1)

#endif /* SOURCE_PLATFORM_H_ */
