Readme.txt
----------
- configMAX_PRIORITIES is to high
- configMINIMAL_STACK_SIZE is low
- APP_task is not waiting
- need configUSE_TRACE_FACILITY needs to be turned on for TCB number
