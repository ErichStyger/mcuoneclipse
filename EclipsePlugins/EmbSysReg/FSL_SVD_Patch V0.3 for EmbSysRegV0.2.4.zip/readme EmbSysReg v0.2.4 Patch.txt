This is a patch on top of the open source EmbSysReg Viewer (http://embsysregview.sourceforge.net/).
Unpack the archive and place it on the eclipse subfolder of your Eclipse IDE.
Note that this patch is for the v0.2.4 plugin.

Content of the patch:
- patch of the 0.2.4 parser to deal with 0xx and similar values in the Freescale CMSIS-SVD files
  (see http://sourceforge.net/p/embsysregview/patches/21/?limit=25)
- additional SVD files for Freescale devices
